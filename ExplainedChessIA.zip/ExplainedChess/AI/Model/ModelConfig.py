class ModelConfig:
    input_row_size = 44
    input_number_of_rows = 40
    total_data = 0
